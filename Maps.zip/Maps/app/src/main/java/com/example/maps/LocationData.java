package com.example.maps;

public class LocationData {

}
